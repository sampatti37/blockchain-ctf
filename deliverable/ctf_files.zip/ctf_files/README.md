These are the remaining files for the CTF. Each level will be called "challenge_n". Once you complete the current challenge, cd into the next challenge directory and read the instructions. In the final challenge, you will need the numeric answer from the web level and the flag string from all subsequent level in order to mint your token. Before starting, run the following commands:

sudo chmod +x ./challenge_1/execute

sudo chmod +x ./challenge_1/challenge_2/challenge_3/verify

This will set up the environment. The first line is specifying the interpreter (bash). The next two lines are simply marking the two binary C files as executables for challenge_1 (level 2) and challenge_3 (level 4) so you can run them to check your work and recieve your flag.