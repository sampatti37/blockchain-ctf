We have changed our code for our Defi Application after finding a bug in our previous version.
We need you to now enter both a CALLDATASIZE and a CALLVALUE to get this contract to execute!
Run ./execute and enter your answers to proceed.