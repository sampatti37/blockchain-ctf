# Collect Your Reward

As a reward for solving our five puzzles, you get a BUF token on the Goerli testnet! You can submit your solution directly on etherscan at: https://goerli.etherscan.io/address/0xb5b587B005284c59662ED616B7Bf23de9dc23B29. Go to the contract -> write contract tab and use the solution drop down to enter your five answers. You will have to connect your ethereum wallet and after clicking write you should now have a BUF token! If it cannot estimate the gas, you probably have one of the solutions wrong so don't submit the transaction.

The BUF token is deployed here https://goerli.etherscan.io/token/0xa71b62cf39714eae8126bf0054a319870155dfeb. Once you successfully submit your solution you will have to import this token on your wallet of choice.